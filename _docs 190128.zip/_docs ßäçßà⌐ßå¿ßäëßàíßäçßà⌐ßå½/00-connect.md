---
# layout : rchive
title: "Connect"
permalink: /connect/
excerpt: "Show that How to connect to Codecademy.com "
last_modified_at: 2018-11-15T09:00:00-04:00
redirect_from:
  - /theme-setup/
toc: true
---
    
    
    
<hr/>

![codecademy]({{ site.baseurl }}/assets/images/codecademy_logo.svg)
#### [https://codecademy.com](https://codecademy.com)
<hr/>    


We learn to Python syntax using the python education infra based on "[codecademy.com](https://codecademy.com)", and it is easily beginner to learn Python syntax without install of Python. 

**설명:** 우리는 [codecademy.com](https://codecademy.com)의 python 교육 환경을 이용하여, 초보자도 쉽게 Python을 추가 살치 없이 아주 쉽게 Python 문법을 배웁니다.
{: .notice--info}
