---
# layout : rchive
title: "PYTHON FINAL PROJECT"
permalink: /python-final-project/
excerpt: "We have finished the python syntax learning project."
last_modified_at: 2019-01-28T09:00:00-04:00
redirect_from:
  - /theme-setup/
toc: false
---
    
<hr style="border: solid 1px #dddddd ;">    
LESSON    

**설명:** [ 학습방향 ]     
Python 기초 작업을 모두 마쳤습니다. 
{: .notice--info}     
     
 <hr style="border: solid 1px #dddddd ;">

![codecademy]({{ site.baseurl }}/assets/images/codecademy/13-python-final-project-01.png)    