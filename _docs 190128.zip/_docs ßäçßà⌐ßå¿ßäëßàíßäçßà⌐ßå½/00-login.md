---
# layout : rchive
title: "LogIn"
permalink: /login/
excerpt: "Shows that How to LogIn to Codecademy.com "
last_modified_at: 2018-11-16T09:00:00-04:00
redirect_from:
  - /theme-setup/
toc: true
---
<hr/>
<br/>   
![signin]({{ site.baseurl }}/assets/images/codecademy/00-login-00.png)
<hr/>    

Fisrt, We have to login for connecting *Codecademy.com* site.    
Enter the `Usnaername` or `Email`, `Password`, and click the `Log in` button. 

**설명:**  로그인을 합니다.     
가입한 `Username` or `Email`, `Password` 를 입력하고, `Log in`를 누른다. 
{: .notice--info}
