---
# layout : rchive
title: "Learn"
permalink: /learn/
excerpt: "Explaining learn."
last_modified_at: 2018-11-17T09:00:00-04:00
redirect_from:
  - /theme-setup/
toc: true
---
    
    
    
<hr/>

![codecademy]({{ site.baseurl }}/assets/images/codecademy/00-learn-00.png)    
<br>

![codecademy]({{ site.baseurl }}/assets/images/codecademy/00-learn-01.png)    

* It is explaining the Python syntax us to learn with.
* Explaining how to write python coder in the edit screen.

**설명:** 우리가 배워야 할 Python 문법을 설명 한다. 그리고 어떻게 `Coding` 화면에 Python 프로그램을 작성하는지를 설명하다.  
{: .notice--info}


<hr/>    
<br>    