---
# layout : rchive
title: "Stuck? Get a hint"
permalink: /stuck-get-a-hint/
excerpt: "Explaining Stuck? Get a hint."
last_modified_at: 2018-11-17T09:00:00-04:00
redirect_from:
  - /theme-setup/
toc: true
---
    
    
    
<hr/>

![codecademy]({{ site.baseurl }}/assets/images/codecademy/00-stuck-00.png)    

![codecademy]({{ site.baseurl }}/assets/images/codecademy/00-hint-00.png)    
<br>
<hr/>

![codecademy]({{ site.baseurl }}/assets/images/codecademy/00-hint-01.png)    

* ① Reference the `Hint` if you hard to understand the instructions.
  - ⓐ Click `Stuck? get a hint`       
  - ⓑ Reference `Hint`     


**설명:**① 미션을 수행하기 어려운 경우 **`Hint`**를 참조한다.    
  ⓐ `Stuck? get a hint` 클릭    
  ⓑ `Hint` 참조    
{: .notice--info}



<hr/>    
<br>    