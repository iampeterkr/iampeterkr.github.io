---
# layout : rchive
title: "SingIn"
permalink: /signin/
excerpt: "Shows that How to Sign In to Codecademy.com "
last_modified_at: 2018-11-16T09:00:00-04:00
redirect_from:
  - /theme-setup/
toc: true
---
<hr/>
<br/>   
![signin]({{ site.baseurl }}/assets/images/codecademy/00-signin-00.png)
<hr/>    

Fisrt, We have to singn in to *Codecademy.com* site.    
Enter the `Usnaername`, `Email`, `Password`, and click the `Start coding now` button. 

**설명:** 먼저, 회원 가입을 해야 한다.    
`Username` , `Email`, `Password` 를 입력하고, `Start coding now`를 누른다. 
{: .notice--info}
