---
# layout : rchive
title: "Report a bug"
permalink: /report-bug/
excerpt: "Explaining Report a bug."
last_modified_at: 2018-11-17T09:00:00-04:00
redirect_from:
  - /theme-setup/
toc: true
---
    
    
    
<hr/>
<br>

![codecademy]({{ site.baseurl }}/assets/images/codecademy/00-report-00.png)    
<br>
<hr/>


![codecademy]({{ site.baseurl }}/assets/images/codecademy/00-report-02.png)    
<br>
<hr/>


![codecademy]({{ site.baseurl }}/assets/images/codecademy/00-report-01.png)    
<hr/>

If you see a bug or any other issue with this page, please report it [here]().   


**설명:**  `here` 를 클릭하면, 설문 조사 화면이 나타난다. 자신의 의견을 선택하고 , 남길 메시지를 적고 제출 하면 된다. 
{: .notice--info}


<hr/>    
<br>    